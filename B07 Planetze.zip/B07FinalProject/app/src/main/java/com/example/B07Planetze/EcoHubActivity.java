package com.example.B07Planetze;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.B07Planetze.R;

public class EcoHubActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eco_hub);
        setTitle("Eco Hub");
    }
}
